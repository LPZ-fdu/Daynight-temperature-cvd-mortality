#!/usr/bin/env Rscript
# Check outcome entry points, input mapping, model selection and result schemas.
# Run from the repository root. No models are fitted and no study files are read.

if (.Platform$OS.type == "windows")
  invisible(Sys.setlocale("LC_CTYPE", "English_United States.utf8"))
options(daynight.stage1.skip_calls = TRUE, daynight.stage2.skip_calls = TRUE,
        daynight.stage3.skip_calls = TRUE, daynight.sensitivity.run = FALSE,
        daynight.collect.run = FALSE)
Sys.setenv(DAYNIGHT_PROJECT_ROOT = normalizePath(getwd(), winslash = "/"))
scripts <- sprintf("%02d_%s.R", 1:5, c("main_risk_models", "main_burden",
                                     "main_heterogeneity", "sensitivity_analysis", "collect_results"))
engines <- lapply(scripts, function(file) {
  e <- new.env(parent = globalenv())
  source(file, local = e, encoding = "UTF-8")
  e
})
codes <- c("I00_I52_I60_I69", "I10_I15", "I21_I22", "I25", "I60_I62", "I63")
for (i in 1:2) {
  e <- engines[[i]]
  captured <- character()
  if (i == 1L) e$run_stage1_outcome <- function(data_path, outcome_code, ...) {
    captured <<- c(captured, outcome_code)
  } else e$run_stage2_outcome <- function(outcome_code, ...) {
    captured <<- c(captured, outcome_code)
  }
  expressions <- parse(scripts[i], encoding = "UTF-8")
  calls <- Filter(function(x) is.call(x) && identical(x[[1L]], as.name("if")) &&
                    grepl("analysis_result <- run_stage", paste(deparse(x), collapse = " ")),
                  as.list(expressions))
  options(daynight.stage1.skip_calls = FALSE, daynight.stage2.skip_calls = FALSE)
  for (x in calls) eval(x, envir = e)
  stopifnot(identical(captured, codes))
  captured <- character()
  e$RUN_I20_I25 <- TRUE
  for (x in calls) eval(x, envir = e)
  stopifnot(identical(captured, c(codes, "I20_I25")))
  options(daynight.stage1.skip_calls = TRUE, daynight.stage2.skip_calls = TRUE)
}
s3 <- engines[[3L]]; s4 <- engines[[4L]]; s5 <- engines[[5L]]
stopifnot(identical(s3$RUN_OUTCOMES, codes), identical(s4$PRIMARY_OUTCOMES, codes),
          identical(s5$OUTCOMES_TO_INCLUDE, codes),
          engines[[2L]]$RUN_COVARIANCE_SOURCE == "csv", s3$COVARIANCE_SOURCE == "csv",
          identical(s4$RUN_VERSION, s5$SENSITIVITY_RUN_VERSION))
stopifnot(nrow(s4$expand_jobs(s4$select_jobs())) == 42L)
s4$INCLUDE_UNSPLIT_IHD <- TRUE
stopifnot(nrow(s4$expand_jobs(s4$select_jobs())) == 49L)
s4$INCLUDE_UNSPLIT_IHD <- FALSE
s4$RUN_MODE <- "selected"
s4$SELECTED_OUTCOMES <- c("I21_I22", "I25")
s4$SELECTED_SENSITIVITIES <- names(s4$SENSITIVITY_NAMES)
stopifnot(nrow(s4$expand_jobs(s4$select_jobs())) == 14L)
s4$RUN_MODE <- "custom"
s4$CUSTOM_RUNS <- data.frame(outcome_code = "I25", sensitivity = "S4_fixed_lags")
stopifnot(nrow(s4$expand_jobs(s4$select_jobs())) == 1L)
catalog <- s5$result_catalog()
stopifnot(catalog[sheet == "Within_outcome_comparisons", primary_file] ==
            "table_12_within_outcome_all_burden_tests.csv",
          is.na(catalog[sheet == "Between_disease_pairwise", sensitivity_file]),
          is.na(catalog[sheet == "Within_outcome_tests", sensitivity_file]),
          catalog[sheet == "Between_disease_global", sensitivity_file] == "heterogeneity_between.csv")
cat("ALL CONFIGURATION CHECKS PASSED\n")
