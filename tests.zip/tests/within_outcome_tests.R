#!/usr/bin/env Rscript
# Validate within-outcome AN contrasts and their CSV/Excel integration.
# Run from the repository root: Rscript tests/within_outcome_tests.R
# Uses analytical fixtures and temporary software-test inputs, not study data.
# No risk models are fitted. No configured study results are read or written.

if (.Platform$OS.type == "windows")
  invisible(Sys.setlocale("LC_CTYPE", "English_United States.utf8"))
options(daynight.stage3.skip_calls = TRUE, daynight.collect.run = FALSE)
repository <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
stopifnot(file.exists("03_main_heterogeneity.R"))
root <- tempfile("daynight_contrast_test_")
dir.create(root, recursive = TRUE)
Sys.setenv(DAYNIGHT_PROJECT_ROOT = repository,
           DAYNIGHT_DATA_ROOT = file.path(root, "data"),
           DAYNIGHT_RESULTS_ROOT = file.path(root, "results"))
s3 <- new.env(parent = globalenv())
sys.source("03_main_heterogeneity.R", envir = s3)
library(data.table)
codes <- s3$RUN_OUTCOMES
components <- s3$COMPONENTS
V <- matrix(c(100, 40, 0, 0, 40, 64, 0, 0,
              0, 0, 25, 5, 0, 0, 5, 16), 4, 4,
            dimnames = list(components, components))
an <- setNames(c(120, 80, 20, 10), components)
raw <- rbindlist(lapply(seq_along(codes), function(i)
  s3$daytime_nighttime_tests(an * (1 + i / 10), V, codes[i], codes[i])))
tests <- s3$add_holm_family(raw, .05, "daytime_nighttime_cold_heat")
cold <- tests[comparison_code == "daytime_nighttime_cold"]
heat <- tests[comparison_code == "daytime_nighttime_heat"]
stopifnot(nrow(tests) == 12L, all(tests$status == "estimated"),
          all(tests$holm_family_size == 12L),
          all(abs(cold$difference_SE - sqrt(84)) < 1e-12),
          all(abs(heat$difference_SE - sqrt(31)) < 1e-12),
          all(abs(cold$difference_AN - 40 * (1 + seq_along(codes) / 10)) < 1e-12),
          all(abs(heat$difference_AN - 10 * (1 + seq_along(codes) / 10)) < 1e-12),
          all(abs(cold$chi_square - cold$difference_AN^2 / 84) < 1e-10),
          all(abs(heat$chi_square - heat$difference_AN^2 / 31) < 1e-10),
          all(abs(cold$p_value - 2 * pnorm(-abs(cold$difference_AN / sqrt(84)))) < 1e-12),
          isTRUE(all.equal(tests$p_holm, p.adjust(tests$p_value, "holm"))))

# An unavailable test keeps its slot in the planned Holm family.
missing <- copy(raw)
missing[1, p_value := NA_real_]
adjusted <- s3$add_holm_family(missing, .05, "daytime_nighttime_cold_heat")
ok <- is.finite(adjusted$p_value)
stopifnot(all(adjusted$holm_family_size == 12L),
          isTRUE(all.equal(adjusted$p_holm[ok], p.adjust(adjusted$p_value[ok], "holm", n = 12L))))

# A zero-variance contrast remains unavailable.
singular <- outer(c(1, 1, 2, 2), c(1, 1, 2, 2))
dimnames(singular) <- list(components, components)
t <- s3$daytime_nighttime_tests(an, singular, codes[1], codes[1])
stopifnot(all(is.na(t$p_value)), all(t$status != "estimated"))

# End-to-end stage-three run from temporary risk/count summaries.
tag <- "software_test"
roots <- setNames(file.path(s3$RESULTS_ROOT, codes, paste0("joint_analysis_", tag)), codes)
states <- s3$STATE_LEVELS
nonreference <- setdiff(states, s3$REF_STATE)
for (i in seq_along(codes)) {
  code <- codes[i]
  folder <- roots[[code]]
  s3$prepare_analysis_directory(folder)
  annual <- CJ(year = 2013:2014, state = states, sorted = FALSE)
  annual[, n_cases := as.numeric(100 + match(state, states) * 9 + (year - 2013) * 4 + i)]
  annual[, n_deaths := sum(n_cases), by = year]
  rr <- data.table(state = states,
                   beta = c(0, .05, .025, .04, .10, .07, .02, .065, .08) * (1 + i / 10),
                   se = c(0, rep(.004, 8)))
  rr[, `:=`(rr = exp(beta), rr_low = exp(beta - 1.96 * se), rr_high = exp(beta + 1.96 * se))]
  counts <- annual[, .(n_cases = sum(n_cases)), by = state]
  rr[, n_cases := counts$n_cases[match(state, counts$state)]]
  rr[, `:=`(n_referents = 2 * n_cases, n_rows = 3 * n_cases, support_status = "observed_estimable")]
  coefficient_covariance <- .004^2 * toeplitz(.2^(0:7))
  dimnames(coefficient_covariance) <- list(nonreference, nonreference)
  fwrite(rr, file.path(folder, "tables/table_04_joint_9_state_rr.csv"))
  fwrite(cbind(data.table(state = nonreference), as.data.table(coefficient_covariance)),
         file.path(folder, "tables/table_04a_joint_logrr_covariance.csv"))
  fwrite(annual, file.path(folder, "tables/table_00c_annual_state_death_counts.csv"))
  metadata <- list(stage1_id = paste0("software_test_", code),
    calibration_id = "software_test", outcome_code = code,
    shared_design = list(analysis_tag = tag, settings = list()),
    reference_method = "rr_tolerance", rr_tolerance = .01,
    state_thresholds = list(day_cold_threshold = 18, day_heat_threshold = 22,
                            night_cold_threshold = 12, night_heat_threshold = 16),
    day_cold_class_lag_days = 1:14, day_heat_class_lag_days = 1:3,
    night_cold_class_lag_days = 1:14, night_heat_class_lag_days = 1:3,
    both_anomaly_policy = "exclude", reference_source_code = codes[1L])
  saveRDS(metadata, file.path(folder, "models/source_parameters.rds"))
  operators <- s3$make_operators(list(annual = annual, states = nonreference))
  f <- 1 - exp(-rr$beta[match(nonreference, rr$state)])
  an <- as.numeric(operators$AN %*% f)
  af <- as.numeric(operators$AF_percent %*% f)
  primary <- data.table(component = c(components, "joint_total"), AN = c(an, sum(an)),
    AF_percent = c(af, sum(af)), share_percent = c(an / sum(an) * 100, 100),
    n_deaths = operators$mean_deaths)
  fwrite(primary, file.path(folder, "tables/table_12_shapley_4_component_burden_mean_annual.csv"))
}
s3$ANALYSIS_DIRS <- roots
run <- s3$run_stage3(n_sim = 1000L, write_xlsx = TRUE)
csv <- file.path(run$output_root, "tables/table_12_within_outcome_all_burden_tests.csv")
exported <- fread(csv)
stopifnot(nrow(exported) == 18L, nrow(run$tables$within) == 6L,
          all(exported$status == "estimated"))
four_component <- run$tables$within
combined <- exported[comparison_code == "four_component_equality"]
stopifnot(isTRUE(all.equal(four_component$p_holm_across_outcomes, combined$p_holm)))
saved <- readRDS(file.path(run$output_root, "models/core_heterogeneity_inference_results.rds"))
stopifnot(isTRUE(all.equal(saved$tables$within_all, run$tables$within_all)))
stage3_workbook <- file.path(run$output_root, "tables/table_core_heterogeneity_inference.xlsx")
stopifnot("H_Within_all" %in% openxlsx::getSheetNames(stage3_workbook))
wx <- openxlsx::read.xlsx(stage3_workbook, sheet = "H_Within_all", startRow = 4)
stopifnot(nrow(wx) == 18L, isTRUE(all.equal(wx$p_holm, exported$p_holm)))

# Result collection copies the primary tests and does not claim sensitivity rows.
s5 <- new.env(parent = globalenv())
sys.source("05_collect_results.R", envir = s5)
s5$MAIN_ANALYSIS_DIRS <- roots
s5$MAIN_HETEROGENEITY_DIR <- run$output_root
catalog <- s5$result_catalog()
definition <- catalog[sheet == "Within_outcome_comparisons"]
stopifnot(nrow(definition) == 1L, definition$core, is.na(definition$sensitivity_file))
models <- s5$make_model_index()[analysis_id == "Main"]
inference <- s5$make_inference_index(models)
collected <- s5$collect_tables(models, inference, catalog)
s5$write_workbook(collected, catalog, models)
wx <- openxlsx::read.xlsx(s5$OUTPUT_FILE, sheet = "Within_outcome_comparisons", startRow = 4)
stopifnot(nrow(wx) == 18L, all(wx$analysis_id == "Main"),
          setequal(wx$outcome_code, exported$outcome_code))
check <- merge(as.data.table(wx)[, .(outcome_code, comparison_code, actual = p_holm)],
               exported[, .(outcome_code, comparison_code, expected = p_holm)],
               by = c("outcome_code", "comparison_code"))
stopifnot(nrow(check) == 18L, isTRUE(all.equal(check$actual, check$expected)))

# A selected subset determines its own declared multiplicity families.
subset_codes <- codes[c(1, 2, 3, 5)]
partial <- s3$run_stage3(outcome_codes = subset_codes, n_sim = 1000L, write_xlsx = FALSE,
                        output_base = file.path(root, "subset_inference"))
stopifnot(nrow(partial$tables$within_all) == 12L,
          all(partial$tables$within$holm_family_size == 4L),
          all(partial$tables$daynight$holm_family_size == 8L),
          nrow(partial$tables$pairwise) == 3L,
          partial$tables$between$df == 6L)
for (code in subset_codes) {
  full <- run$tables$daynight[outcome_code == code]
  part <- partial$tables$daynight[outcome_code == code]
  stopifnot(identical(full$p_value, part$p_value))
}
cat("ALL WITHIN-OUTCOME CONTRAST AND EXPORT CHECKS PASSED\n", root, "\n")
