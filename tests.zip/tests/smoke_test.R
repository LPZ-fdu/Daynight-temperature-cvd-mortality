#!/usr/bin/env Rscript
# Synthetic integration test of the five analysis scripts.
# Run from the repository root: Rscript tests/smoke_test.R
# No study data are used. Results are written to a temporary directory.
# Simulation counts and image resolution are reduced for this test only.

if (.Platform$OS.type == "windows") Sys.setlocale("LC_CTYPE", "English_United States.utf8")
options(daynight.stage1.skip_calls = TRUE, daynight.stage2.skip_calls = TRUE,
        daynight.stage3.skip_calls = TRUE, daynight.sensitivity.run = FALSE,
        daynight.collect.run = FALSE, warn = 1)
repository <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
stopifnot(file.exists(file.path(repository, "01_main_risk_models.R")))
root <- Sys.getenv("DAYNIGHT_TEST_ROOT", unset = tempfile("daynight_synthetic_"))
dir.create(root, recursive = TRUE, showWarnings = FALSE)
root <- normalizePath(root, winslash = "/", mustWork = TRUE)
Sys.setenv(DAYNIGHT_PROJECT_ROOT = repository,
           DAYNIGHT_DATA_ROOT = file.path(root, "data"),
           DAYNIGHT_RESULTS_ROOT = file.path(root, "results"))
dir.create(file.path(root, "data", "matched"), recursive = TRUE)
dir.create(file.path(root, "data", "pollution"), recursive = TRUE)
writeLines("SYNTHETIC SOFTWARE TEST ONLY; NOT STUDY RESULTS.", file.path(root, "TEST_ONLY.txt"))
cat("Synthetic test output:", root, "\n")
s1 <- new.env(parent = globalenv())
source("01_main_risk_models.R", local = s1, encoding = "UTF-8")
library(data.table)
set.seed(9625)
make_data <- function(nsets = 1800L) {
  n <- nsets * 4L
  common <- rnorm(n)
  day_base <- 20 + 4 * common + rnorm(n, sd = 3)
  night_base <- 14 + 3 * common + rnorm(n, sd = 4)
  years <- 2013L + seq_len(nsets) %% 7L
  d <- data.table(id = rep(seq_len(nsets), each = 4L), case = 0L,
                  date = as.IDate(paste0(rep(years, each = 4L), "-04-01")) +
                    rep(0:3 * 7L, nsets), holiday = rbinom(n, 1, .1))
  for (j in 1:21) {
    d[, (sprintf("temp_day_lag%02d", j)) := day_base + rnorm(n, sd = 2.5)]
    d[, (sprintf("temp_night_lag%02d", j)) := night_base + rnorm(n, sd = 2.5)]
  }
  for (j in 1:3) {
    d[, (sprintf("rh_day_lag%02d", j)) := runif(n, 25, 90)]
    d[, (sprintf("rh_night_lag%02d", j)) := runif(n, 30, 95)]
  }
  eta <- .022 * (day_base - 20)^2 + .022 * (night_base - 14)^2 + .05 * d$holiday
  rows <- vapply(seq_len(nsets), function(i) {
    rr <- (i - 1L) * 4L + 1:4
    sample(rr, 1L, prob = exp(eta[rr] - max(eta[rr])))
  }, integer(1))
  d[rows, case := 1L]
  d
}
d <- make_data()
saveRDS(d[id <= 900], s1$MATCHED_FILES[["I00_I52"]])
second <- copy(d[id > 900]); second[, id := id - 900L]
saveRDS(second, s1$MATCHED_FILES[["I60_I69"]])
for (code in c("I10_I15", "I21_I22", "I25", "I60_I62", "I63"))
  saveRDS(make_data(1400L), s1$MATCHED_FILES[[code]])
s1$N_MMT_CI_SIM <- 80L
s1$N_SIM <- 40L
s1$FIG_DPI <- 50L
s1$run_stage1_internal_checks()

# Connected reference intervals exclude separate low-risk regions.
curve <- data.table(temperature = seq(-5, 5, by = .01))
curve[, logrr := .02 * temperature^2]
band <- s1$rr_tolerance_band(curve, 0, .01)
stopifnot(abs(band$high - sqrt(log1p(.01) / .02)) < 1e-4)
curve2 <- data.table(temperature = -5:5,
                     logrr = c(1, 0, 1, 1, .2, 0, .2, 1, 1, 0, 1))
band2 <- s1$rr_tolerance_band(curve2, 0, .05)
stopifnot(band2$low > -1, band2$high < 1)

codes <- c("I00_I52_I60_I69", "I10_I15", "I21_I22", "I25", "I60_I62", "I63")
roots <- setNames(character(length(codes)), codes)
for (code in codes) {
  paths <- if (code == codes[1]) s1$DATA_PATHS else s1$MATCHED_FILES[[code]]
  fit <- s1$run_stage1_outcome(paths, code, paste("Synthetic", code))
  roots[[code]] <- fit$output_root
  stopifnot(nrow(fread(file.path(fit$output_root, "tables/table_04_joint_9_state_rr.csv"))) == 9L,
            !file.exists(file.path(fit$output_root, "tables/table_12_shapley_4_component_burden_mean_annual.csv")),
            setequal(list.files(fit$output_root), c("tables", "figures", "models", "plot_data")))
}

s2 <- new.env(parent = globalenv())
source("02_main_burden.R", local = s2, encoding = "UTF-8")
s2$FIG_DPI <- 50L
s2$ANALYSIS_DIRS <- roots
s2$run_internal_checks()
risk_paths <- file.path(roots, "tables/table_04_joint_9_state_rr.csv")
risk_hash <- unname(tools::md5sum(risk_paths))
for (code in codes) {
  out <- s2$run_stage2_outcome(code, n_sim = 40L)
  x <- fread(file.path(roots[[code]], "tables/table_12_shapley_4_component_burden_mean_annual.csv"))
  stopifnot(abs(sum(x[component != "joint_total", AN]) - x[component == "joint_total", AN]) < 1e-8)
}
stopifnot(identical(risk_hash, unname(tools::md5sum(risk_paths))))
s3 <- new.env(parent = globalenv())
source("03_main_heterogeneity.R", local = s3, encoding = "UTF-8")
s3$ANALYSIS_DIRS <- roots
inference <- s3$run_stage3(n_sim = 1000L)
stopifnot(nrow(inference$tables$pairwise) == 10L,
          nrow(inference$tables$within) == 6L,
          nrow(inference$tables$within_all) == 18L)
comparisons <- inference$tables$within_all
stopifnot(all(comparisons[, .N, by = outcome_code]$N == 3L))
for (family in unique(comparisons$holm_family)) {
  test_family <- comparisons[holm_family == family]
  stopifnot(isTRUE(all.equal(test_family$p_holm, p.adjust(test_family$p_value, "holm"))))
}

s4 <- new.env(parent = globalenv())
source("04_sensitivity_analysis.R", local = s4, encoding = "UTF-8")
stopifnot(nrow(s4$select_jobs()) == 24L)
s4$RUN_MODE <- "selected"
s4$SELECTED_OUTCOMES <- c("I21_I22", "I25")
s4$SELECTED_SENSITIVITIES <- "S2_mmt_ci"
stopifnot(nrow(s4$select_jobs()) == 2L)
s4$RUN_MODE <- "all"
stopifnot(nrow(s4$expand_jobs(s4$select_jobs())) == 42L)
s4$INCLUDE_UNSPLIT_IHD <- TRUE
stopifnot(nrow(s4$expand_jobs(s4$select_jobs())) == 49L)
s4$INCLUDE_UNSPLIT_IHD <- FALSE
stopifnot(inherits(try(s3$run_stage3(outcome_codes = c("I20_I25", "I21_I22")), silent = TRUE), "try-error"))
set.seed(913)
for (code in codes) {
  sources <- s4$OUTCOME_SOURCES[[code]]
  pieces <- lapply(seq_along(sources), function(i) {
    raw <- as.data.table(readRDS(sources[i]))
    p <- raw[, .(source_code = names(sources)[i], source_id = as.character(id), date, case)]
    pm <- pmax(1, 30 + .7 * raw$temp_day_lag01 + rnorm(nrow(raw), sd = 8))
    for (poll in c("PM25", "NO2", "O3_8H")) for (period in c("day", "night")) for (lag in 0:2)
      p[, (paste0(poll, "_", period, "_lag", lag)) := pm + rnorm(nrow(raw), sd = 3)]
    p[seq.int(10, nrow(p), by = 100L), PM25_day_lag0 := NA_real_]
    p
  })
  p <- rbindlist(pieces)
  saveRDS(p[sample(.N)], s4$POLLUTION_FILES[[code]])
}
s4$N_MMT_DRAWS <- 80L
s4$N_BURDEN_DRAWS <- 40L
s4$N_HETEROGENEITY_DRAWS <- 1000L
s4$WRITE_FIGURES <- FALSE
s4$CONTINUE_ON_ERROR <- TRUE
status <- s4$run_sensitivity_analysis()
fwrite(status, file.path(root, "test_status.csv"))
stopifnot(nrow(status) == 42L, all(status$status == "completed"))
primary <- readRDS(file.path(roots[[codes[1]]], "models/shared_analysis_design.rds"))
for (code in codes) {
  for (poll in names(s4$POLLUTION_MODELS)) {
    base <- file.path(s4$OUTPUT_ROOT, "S1_pollution", code)
    a <- readRDS(file.path(base, paste0(poll, "_adjusted"), "models/source_parameters.rds"))
    stopifnot(a$n_cases > 0, a$n_rows_model > a$n_cases)
    flows <- fread(file.path(base, paste0(poll, "_adjusted"), "tables/table_pollution_sample_flow.csv"))
    stopifnot(nrow(flows) > 0)

  }
  d2 <- readRDS(file.path(s4$OUTPUT_ROOT, "S2_mmt_ci", code, "main/models/shared_analysis_design.rds"))
  d3 <- readRDS(file.path(s4$OUTPUT_ROOT, "S3_outcome_lags", code, "main/models/shared_analysis_design.rds"))
  d4 <- readRDS(file.path(s4$OUTPUT_ROOT, "S4_fixed_lags", code, "main/models/shared_analysis_design.rds"))
  stopifnot(identical(d2$lags, primary$lags), identical(d2$settings$reference_method, "mmt_ci"),
            identical(d3$thresholds, primary$thresholds), identical(d4$thresholds, primary$thresholds),
            identical(d4$lags$day_cold$lag_days, 0:20), identical(d4$lags$night_heat$lag_days, 0:2))
}
h3 <- fread(file.path(s4$OUTPUT_ROOT, "_heterogeneity/S3_outcome_lags/main/tables/heterogeneity_between.csv"))
stopifnot(is.na(h3$p_value), grepl("incompatible_exposure_definitions", h3$status, fixed = TRUE))

completed <- s4$discover_completed_models()
stopifnot(nrow(completed) == 42L)
saved_version <- s4$RUN_VERSION
s4$RUN_VERSION <- "another_analysis"
stopifnot(!s4$model_is_complete(codes[1], "S2_mmt_ci", "main"))
s4$RUN_VERSION <- saved_version
s4$get_primary_context <- function(...) stop("A completed restart must not load primary data.")
fit_files <- file.path(completed$output_root, "models/source_parameters.rds")
hashes <- unname(tools::md5sum(fit_files))
resumed <- s4$run_sensitivity_analysis()
stopifnot(all(resumed$status == "skipped_completed"), identical(hashes, unname(tools::md5sum(fit_files))))

s5 <- new.env(parent = globalenv())
source("05_collect_results.R", local = s5, encoding = "UTF-8")
s5$collect_main_and_sensitivity()
workbook <- openxlsx::loadWorkbook(s5$OUTPUT_FILE)
read_result <- function(sheet) as.data.table(openxlsx::read.xlsx(workbook,
  sheet = sheet, startRow = 4, check.names = FALSE))
risks <- read_result("Joint_state_RR")
models <- unique(risks[, .(analysis_id, outcome_code, model_variant)])
stopifnot(nrow(models[analysis_id == "Main"]) == 6L,
          nrow(models[analysis_id != "Main"]) == 42L,
          all(risks[, .N, by = .(analysis_id, outcome_code, model_variant)]$N == 9L))
checks <- read_result("Reconstruction_checks")
stopifnot(all(checks$max_absolute_difference < 1e-8, na.rm = TRUE))
daynight <- read_result("Within_outcome_comparisons")
stopifnot(nrow(daynight) == 18L, all(daynight$analysis_id == "Main"),
          all(daynight$outcome_code %in% codes))
check <- merge(daynight[, .(outcome_code, comparison_code, exported = p_holm)],
               comparisons[, .(outcome_code, comparison_code, expected = p_holm)],
               by = c("outcome_code", "comparison_code"))
stopifnot(nrow(check) == 18L, isTRUE(all.equal(check$exported, check$expected)))
stopifnot(all(read_result("Between_disease_pairwise")$analysis_id == "Main"),
          all(read_result("Within_outcome_tests")$analysis_id == "Main"),
          nrow(read_result("Between_disease_global")[analysis_id != "Main"]) == 7L)
s5$SENSITIVITY_RUN_VERSION <- "another_analysis"
excluded <- s5$collect_tables(s5$make_model_index(), s5$make_inference_index(s5$make_model_index()), s5$result_catalog())
stopifnot(all(excluded$tables$Joint_state_RR$analysis_id == "Main"))
writeLines(capture.output(sessionInfo()), file.path(root, "sessionInfo.txt"))
saveRDS(list(root = root, main = roots, inference = inference$output_root,
             sensitivity = s4$OUTPUT_ROOT, workbook = s5$OUTPUT_FILE),
        file.path(root, "test_outputs.rds"))
cat("ALL SYNTHETIC INTEGRATION CHECKS PASSED\n", root, "\n")
